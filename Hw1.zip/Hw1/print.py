__author__ = 'Tramel Jones'

"""
Prints name and address and phone number
"""

print(" Tramel Jones \n tramel.jones@gmail.com \n 708-768-8139")
